package nt222gp_assign4.stack;

public class StackException extends Exception{
	public StackException() {
		super("Stack Array Exception!");
	}
	
	public StackException(String message) {
		super(message);
	}
}
