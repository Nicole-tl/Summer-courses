package nt222gp_assign1;

public class Print {
	public static void main(String[] args) {
		/* Part 1 - in one line */
		System.out.println("Write once, run everywhere!");
		
		System.out.println("\n");
		
		/* Part 2 - in four line*/
		System.out.println("Write");
		System.out.println("once,");
		System.out.println("run"); 
		System.out.println("everywhere!"); 
		
		System.out.println("\n");

		/* Part 3 - inside a rectangle*/
		System.out.println("****************************************");
		System.out.println("*        Write once, run everywhere!   *");
		System.out.println("****************************************");

	}
	
}
